const cp = require('child_process');
const { promisify } = require('util')
const execAsync = promisify(cp.exec)

module.exports.getInstalledPackages = async () => {
    const { stdout } = await execAsync('pacstall -L')
    return stdout.split('\n').map(it => it.trim()).filter(it => !!it)
}

module.exports.getPackageInstalledVersion = async (/** @type {string} */ pkgName) => {
    console.log(pkgName)
    const { stdout } = await execAsync('pacstall -Qi ' + pkgName)
    return stdout
        .split('\n')
        .map(it => it.trim())
        .find(it => it.includes('version'))
        .split('\x1B[1;32mversion\x1B(B\x1B[m: ')[1]
}